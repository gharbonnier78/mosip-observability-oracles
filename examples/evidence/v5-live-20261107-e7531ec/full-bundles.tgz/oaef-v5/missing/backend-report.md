# OAEF V5 — backend observation for s1-0259e09626d6

**Result: INCONCLUSIVE** — S1 synthetic only; not MOSIP qualification.

- Traces returned: 100/100
- Structured business logs: 299/300
- Metric checks: Counter({'PASS': 12})
- Event/span failures: 2
- Query attempts: 22; truncated Loki query: False
- Collection errors: {}; malformed log entries: []

Important: A missing telemetry record is not proof the business activity did not occur.
Manifest hashes are local integrity checks; not signatures or WORM.
